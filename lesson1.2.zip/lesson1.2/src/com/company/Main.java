package com.company;

public class Main {

    public static void main(String[] args) {

        int temperature = 20;

        if(temperature == 20) {

        }

